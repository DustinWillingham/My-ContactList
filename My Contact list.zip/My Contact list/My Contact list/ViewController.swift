//
//  ViewController.swift
//  My Contact list
//
//  Created by Gillian Davis on 4/5/21.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

